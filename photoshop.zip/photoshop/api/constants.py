# The photoshop version to COM progid mappings.
PHOTOSHOP_VERSION_MAPPINGS = {
    "2021": "150",
    "2020": "140",
    "2019": "130",
    "2018": "120",
    "2017": "110",
}
